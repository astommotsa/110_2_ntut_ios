//
//  ViewController.swift
//  midterm
//
//  Created by 蕭岳 on 2022/5/5.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var calculate_label: UILabel!
    @IBOutlet weak var answer_label: UILabel!
    @IBOutlet var number_button: [UIButton]!
    @IBOutlet weak var clear_button: UIButton!
    @IBOutlet var not_number_button: [UIButton]!
    
    var not_number_char = ["/", "*", "-", "+"]
    var ac = true
    var labelHasPoint = false
    var isHighlighted = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func clean(_ sender: UIButton) {
        if(ac){
            calculate_label.text = "";
            answer_label.text = "0";
            labelHasPoint = false
            if(isHighlighted != ""){
                not_number_button[Int(isHighlighted)!].backgroundColor = UIColor.systemOrange
                not_number_button[Int(isHighlighted)!].tintColor = UIColor.white
                isHighlighted = ""
            }
        }else{
            if(isHighlighted != ""){
                ac = true
                clear_button.setTitle("AC", for: UIControl.State.normal)
            }else{
                while(calculate_label.text?.last?.isNumber == true || calculate_label.text?.last == "."){
                    _ = calculate_label.text?.popLast()
                }
                if(calculate_label.text?.last == "/"){
                    not_number_button[0].backgroundColor = UIColor.white
                    not_number_button[0].tintColor = UIColor.systemOrange
                    isHighlighted = "0"
                }else if(calculate_label.text?.last == "*"){
                    not_number_button[1].backgroundColor = UIColor.white
                    not_number_button[1].tintColor = UIColor.systemOrange
                    isHighlighted = "1"
                }else if(calculate_label.text?.last == "-"){
                    not_number_button[2].backgroundColor = UIColor.white
                    not_number_button[2].tintColor = UIColor.systemOrange
                    isHighlighted = "2"
                }else if(calculate_label.text?.last == "+"){
                    not_number_button[3].backgroundColor = UIColor.white
                    not_number_button[3].tintColor = UIColor.systemOrange
                    isHighlighted = "3"
                }
                answer_label.text = "0"
                ac = true
                labelHasPoint = false
                clear_button.setTitle("AC", for: UIControl.State.normal)
            }
        }
    }
    
    @IBAction func numbers_click(_ sender: UIButton) {
        var index = 0
        while(sender != number_button[index]){
            index += 1
        }
        if(calculate_label.text == ""){
            calculate_label.text = String(index)
        }else{
            calculate_label.text = calculate_label.text! + String(index)
        }
        
        if(ac){
            ac = false
            clear_button.setTitle("C", for: UIControl.State.normal)
        }
        
        if(isHighlighted != ""){
            not_number_button[Int(isHighlighted)!].backgroundColor = UIColor.systemOrange
            not_number_button[Int(isHighlighted)!].tintColor = UIColor.white
            isHighlighted = ""
        }
    }
    
    @IBAction func point_click(_ sender: UIButton) {
        if(!labelHasPoint){
            calculate_label.text = calculate_label.text! + "."
            labelHasPoint = true
        }
    }
    
    @IBAction func calculator_click(_ sender: UIButton) {
        var index = 0
        while(sender != not_number_button[index]){
            index += 1
        }
        if(calculate_label.text == ""){
        }else if calculate_label.text?.last?.isNumber == true{
            calculate_label.text = calculate_label.text! + not_number_char[index]
            labelHasPoint = false
            sender.backgroundColor = UIColor.white
            sender.tintColor = UIColor.systemOrange
            isHighlighted = String(index)
        }else if(isHighlighted != ""){
            _ = calculate_label.text?.popLast()
            calculate_label.text = calculate_label.text! + not_number_char[index]
            
            not_number_button[Int(isHighlighted)!].backgroundColor = UIColor.systemOrange
            not_number_button[Int(isHighlighted)!].tintColor = UIColor.white
            
            sender.backgroundColor = UIColor.white
            sender.tintColor = UIColor.systemOrange
            isHighlighted = String(index)
        }
    }
    
    @IBAction func percent(_ sender: UIButton) {
//        if(calculate_label.text == ""){
//        }else if calculate_label.text?.last?.isNumber == true{
//            calculate_label.text = calculate_label.text! + "%"
//        }
    }
    
    @IBAction func calculate(_ sender: UIButton) {
        //labelHasPoint = false
        if(isHighlighted == ""){
            answer_label.text = stringToAnswer(equation: realExpress(labelInput: calculate_label.text!))
        }
    }
    
    func stringToAnswer(equation: String) -> String {
        let expr = NSExpression(format: equation)
        if let result = expr.expressionValue(with: nil, context: nil) as? Double {
            if(result.isInfinite){
                return "0"
            }
            if(floor(result) == result){
                return String(Int(result))
            }else{
                return String(result)
            }
        } else {
            return "failed"
        }
    }
    
    func realExpress(labelInput: String) -> String {
        var resultString = ""
        var getPoint = false
        var counter = labelInput.startIndex
        while(counter != labelInput.endIndex){
            if(labelInput[counter] == "."){
                getPoint = true
            }else if(!labelInput[counter].isNumber){
                if(!getPoint){
                    resultString += ".0"
                }else{
                    getPoint = false
                }
            }
            resultString += String(labelInput[counter])
            counter = labelInput.index(after: counter)
        }
        
        if(!getPoint){
            resultString += ".0"
        }
        
        return resultString
    }

}

